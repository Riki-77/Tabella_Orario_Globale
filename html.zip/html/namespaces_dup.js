var namespaces_dup =
[
    [ "F1", "namespace_f1.html", [
      [ "get_teacher_schedule", "namespace_f1.html#a56de1872fb342b44cc2307f0830ca093", null ],
      [ "schedule", "namespace_f1.html#abd1b0132f586d2ad4e7ae739d135ede1", null ],
      [ "teacher_name", "namespace_f1.html#ab1cfd638ede055e2e8f4eda6ef1ce7dc", null ],
      [ "total_hours", "namespace_f1.html#ac86a1aad428da70d1d32f97d394a817c", null ]
    ] ],
    [ "F2", "namespace_f2.html", [
      [ "orario_docente", "namespace_f2.html#a61d9675c41c2cb04b7363665cf0be827", null ],
      [ "docente", "namespace_f2.html#a385795875c171b8c4984e3984f5c3b3c", null ],
      [ "orario", "namespace_f2.html#aaf7fbb6ffad67d7f4401bda0c89c46e6", null ]
    ] ],
    [ "F3", "namespace_f3.html", [
      [ "orario_docente", "namespace_f3.html#a61d9675c41c2cb04b7363665cf0be827", null ],
      [ "docente", "namespace_f3.html#a385795875c171b8c4984e3984f5c3b3c", null ],
      [ "orario", "namespace_f3.html#aaf7fbb6ffad67d7f4401bda0c89c46e6", null ]
    ] ],
    [ "F4", "namespace_f4.html", [
      [ "docenti_lezione_ora", "namespace_f4.html#ac522b6c4f2bff625a6097eac81b85ccc", null ],
      [ "elenco_docenti", "namespace_f4.html#ae43566d93853aea5ca31663d963587f6", null ],
      [ "giorno", "namespace_f4.html#aa16f54fedd90dabbd71b25791c01f6d4", null ],
      [ "ora", "namespace_f4.html#aa758caee9069cbca3f9889325c21fd4d", null ],
      [ "totale_docenti", "namespace_f4.html#a8974c70cebff04cc2ca631556e990e55", null ]
    ] ],
    [ "main", "namespacemain.html", [
      [ "main", "namespacemain.html#a51af30a60f9f02777c6396b8247e356f", null ]
    ] ]
];