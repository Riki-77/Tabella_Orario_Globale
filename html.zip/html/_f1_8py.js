var _f1_8py =
[
    [ "get_teacher_schedule", "_f1_8py.html#a56de1872fb342b44cc2307f0830ca093", null ],
    [ "schedule", "_f1_8py.html#abd1b0132f586d2ad4e7ae739d135ede1", null ],
    [ "teacher_name", "_f1_8py.html#ab1cfd638ede055e2e8f4eda6ef1ce7dc", null ],
    [ "total_hours", "_f1_8py.html#ac86a1aad428da70d1d32f97d394a817c", null ]
];