var _f2_8py =
[
    [ "orario_docente", "_f2_8py.html#a61d9675c41c2cb04b7363665cf0be827", null ],
    [ "docente", "_f2_8py.html#a385795875c171b8c4984e3984f5c3b3c", null ],
    [ "orario", "_f2_8py.html#aaf7fbb6ffad67d7f4401bda0c89c46e6", null ]
];