var files_dup =
[
    [ "F1.py", "_f1_8py.html", "_f1_8py" ],
    [ "F2.py", "_f2_8py.html", "_f2_8py" ],
    [ "F3.py", "_f3_8py.html", "_f3_8py" ],
    [ "F4.py", "_f4_8py.html", "_f4_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ]
];