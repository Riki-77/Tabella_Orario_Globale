var _f4_8py =
[
    [ "docenti_lezione_ora", "_f4_8py.html#ac522b6c4f2bff625a6097eac81b85ccc", null ],
    [ "elenco_docenti", "_f4_8py.html#ae43566d93853aea5ca31663d963587f6", null ],
    [ "giorno", "_f4_8py.html#aa16f54fedd90dabbd71b25791c01f6d4", null ],
    [ "ora", "_f4_8py.html#aa758caee9069cbca3f9889325c21fd4d", null ],
    [ "totale_docenti", "_f4_8py.html#a8974c70cebff04cc2ca631556e990e55", null ]
];