var searchData=
[
  ['giorno_0',['giorno',['../namespace_f4.html#aa16f54fedd90dabbd71b25791c01f6d4',1,'F4']]]
];
