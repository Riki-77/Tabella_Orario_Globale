var searchData=
[
  ['ora_0',['ora',['../namespace_f4.html#aa758caee9069cbca3f9889325c21fd4d',1,'F4']]],
  ['orario_1',['orario',['../namespace_f2.html#aaf7fbb6ffad67d7f4401bda0c89c46e6',1,'F2.orario'],['../namespace_f3.html#aaf7fbb6ffad67d7f4401bda0c89c46e6',1,'F3.orario']]],
  ['orario_5fdocente_2',['orario_docente',['../namespace_f2.html#a61d9675c41c2cb04b7363665cf0be827',1,'F2.orario_docente()'],['../namespace_f3.html#a61d9675c41c2cb04b7363665cf0be827',1,'F3.orario_docente()']]]
];
