var searchData=
[
  ['ora_0',['ora',['../namespace_f4.html#aa758caee9069cbca3f9889325c21fd4d',1,'F4']]],
  ['orario_1',['orario',['../namespace_f2.html#aaf7fbb6ffad67d7f4401bda0c89c46e6',1,'F2.orario'],['../namespace_f3.html#aaf7fbb6ffad67d7f4401bda0c89c46e6',1,'F3.orario']]]
];
