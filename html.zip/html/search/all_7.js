var searchData=
[
  ['teacher_5fname_0',['teacher_name',['../namespace_f1.html#ab1cfd638ede055e2e8f4eda6ef1ce7dc',1,'F1']]],
  ['total_5fhours_1',['total_hours',['../namespace_f1.html#ac86a1aad428da70d1d32f97d394a817c',1,'F1']]],
  ['totale_5fdocenti_2',['totale_docenti',['../namespace_f4.html#a8974c70cebff04cc2ca631556e990e55',1,'F4']]]
];
