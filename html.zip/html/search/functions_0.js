var searchData=
[
  ['docenti_5flezione_5fora_0',['docenti_lezione_ora',['../namespace_f4.html#ac522b6c4f2bff625a6097eac81b85ccc',1,'F4']]]
];
